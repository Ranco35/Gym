import React from 'react';
import { Menu, Home, Dumbbell, LineChart, User, Library } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center">
            <button className="p-2 rounded-md hover:bg-gray-100 lg:hidden">
              <Menu className="h-6 w-6 text-gray-600" />
            </button>
            <h1 className="ml-2 text-xl font-bold text-gray-900">GymTracker</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-around h-16">
            <NavItem icon={<Home />} label="Home" active />
            <NavItem icon={<Dumbbell />} label="Workout" />
            <NavItem icon={<LineChart />} label="Progress" />
            <NavItem icon={<Library />} label="Library" />
            <NavItem icon={<User />} label="Profile" />
          </div>
        </div>
      </nav>
    </div>
  );
}

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
}

function NavItem({ icon, label, active }: NavItemProps) {
  return (
    <button className={`flex flex-col items-center justify-center w-full
      ${active ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'}`}>
      {React.cloneElement(icon as React.ReactElement, { 
        className: 'h-6 w-6' 
      })}
      <span className="mt-1 text-xs">{label}</span>
    </button>
  );
}