import React from 'react';
import { Activity, TrendingUp, Calendar, Clock } from 'lucide-react';

export function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard
          icon={<Activity className="h-6 w-6 text-blue-500" />}
          label="This Week"
          value="4 Workouts"
        />
        <StatCard
          icon={<TrendingUp className="h-6 w-6 text-green-500" />}
          label="Volume"
          value="+12.5%"
        />
        <StatCard
          icon={<Calendar className="h-6 w-6 text-purple-500" />}
          label="Streak"
          value="8 Days"
        />
        <StatCard
          icon={<Clock className="h-6 w-6 text-orange-500" />}
          label="Avg. Duration"
          value="72 min"
        />
      </div>

      {/* Next Workout Preview */}
      <section className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Today's Workout</h2>
        <div className="space-y-4">
          <WorkoutExercisePreview
            name="Barbell Bench Press"
            sets="4 sets × 8-10 reps"
            previous="80kg × 10,10,9,8"
          />
          <WorkoutExercisePreview
            name="Incline Dumbbell Press"
            sets="3 sets × 12 reps"
            previous="30kg × 12,12,10"
          />
          <WorkoutExercisePreview
            name="Cable Flyes"
            sets="3 sets × 15 reps"
            previous="15kg × 15,15,15"
          />
          <button className="w-full mt-4 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
            Start Workout
          </button>
        </div>
      </section>
    </div>
  );
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
}

function StatCard({ icon, label, value }: StatCardProps) {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center space-x-3">
        {icon}
        <div>
          <p className="text-sm text-gray-500">{label}</p>
          <p className="text-lg font-semibold text-gray-900">{value}</p>
        </div>
      </div>
    </div>
  );
}

interface WorkoutExercisePreviewProps {
  name: string;
  sets: string;
  previous: string;
}

function WorkoutExercisePreview({ name, sets, previous }: WorkoutExercisePreviewProps) {
  return (
    <div className="border-b border-gray-200 pb-4 last:border-0">
      <h3 className="font-medium text-gray-900">{name}</h3>
      <p className="text-sm text-gray-600">{sets}</p>
      <p className="text-xs text-gray-500 mt-1">Previous: {previous}</p>
    </div>
  );
}