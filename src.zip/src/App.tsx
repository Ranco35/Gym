import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { AuthPage } from './components/auth/AuthPage';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  return (
    <Layout>
      <Dashboard />
    </Layout>
  );
}

export default App;