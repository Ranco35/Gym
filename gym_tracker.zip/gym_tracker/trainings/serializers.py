from rest_framework import serializers
from .models import Training

class TrainingSerializer(serializers.ModelSerializer):
    """
    Serializer para el modelo Training.
    """
    class Meta:
        model = Training
        fields = '__all__'