from django.db import models
from django.conf import settings
from .models import Exercise  # Asegúrate de importar el modelo Exercise

class Training(models.Model):
    """
    Modelo para almacenar la información de los entrenamientos.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    exercise = models.ForeignKey(Exercise, on_delete=models.CASCADE)  # Relación con el ejercicio
    # ... otros campos que necesites, como series, repeticiones, peso, fecha, etc.

    def __str__(self):
        return f"{self.user.username} - {self.exercise.name}"