from django.db import models
from django.conf import settings  # Importa settings para acceder al modelo de usuario

class Workout(models.Model):
    """
    Modelo para almacenar la información de los entrenamientos.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)  # Relación con el usuario
    name = models.CharField(max_length=255)  # Nombre del entrenamiento
    date = models.DateField(auto_now_add=True)  # Fecha del entrenamiento
    # ... otros campos que necesites, como duración, notas, etc.

    def __str__(self):
        return f"{self.name} - {self.user.username}"