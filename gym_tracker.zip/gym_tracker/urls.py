from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/users/', include('gym_tracker.users.urls')),
    path('api/workouts/', include('gym_tracker.workouts.urls')),
    path('api/exercises/', include('gym_tracker.exercises.urls')),
    path('api/trainings/', include('gym_tracker.trainings.urls')), 
    # ... otras URLs que puedas necesitar
]